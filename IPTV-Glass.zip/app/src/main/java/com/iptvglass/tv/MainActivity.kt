package com.iptvglass.tv

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val categories = listOf(
        "Hindi", "Punjabi", "Tamil", "Telugu", "Malayalam", "Kannada",
        "Bengali", "Marathi", "Gujarati", "Odia", "Assamese", "English",
        "Kids", "News", "Sports", "Movies", "Entertainment", "Music"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tileRow = findViewById<RecyclerView>(R.id.tileRow)
        tileRow.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tileRow.setHasFixedSize(true)
        tileRow.adapter = TileAdapter(categories) { name ->
            Toast.makeText(this, name, Toast.LENGTH_SHORT).show()
        }

        val continueRow = findViewById<RecyclerView>(R.id.continueRow)
        continueRow.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        continueRow.setHasFixedSize(true)
        continueRow.adapter = TileAdapter(listOf("Abhi kuch nahi")) { }
    }
}
